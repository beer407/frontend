import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  login(email: string, password: string): void {
    // TODO: เชื่อม API เข้าสู่ระบบ
    console.log('Login:', email, password);
  }

  logout(): void {
    // TODO: ล้าง token และกลับไปหน้า login
  }
}
