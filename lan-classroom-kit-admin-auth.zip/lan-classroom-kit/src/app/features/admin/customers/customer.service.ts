import { Injectable } from '@angular/core';
import { Customer } from './customer.model';

@Injectable({ providedIn: 'root' })
export class CustomerService {
  // TODO: เปลี่ยนเป็น HttpClient และ URL ของ API ที่ทีมตกลงกัน
  getAll(): Customer[] {
    return [];
  }
}
