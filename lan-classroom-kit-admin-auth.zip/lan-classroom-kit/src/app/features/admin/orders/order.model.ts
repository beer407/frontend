export interface Order {
  id: number;
  customerId: number;
  status: 'pending' | 'confirmed' | 'preparing' | 'ready' | 'delivering' | 'completed' | 'cancelled';
  total: number;
  createdAt?: string;
}
