import { Component } from '@angular/core';

@Component({
  selector: 'app-customers',
  standalone: true,
  templateUrl: './customers.component.html',
  styleUrl: './customers.component.css',
})
export class CustomersComponent {
  // TODO: เพิ่มการโหลด ค้นหา เพิ่ม แก้ไข และลบข้อมูลลูกค้า
}
