import { Routes } from '@angular/router';

export const ADMIN_ROUTES: Routes = [
  { path: 'dashboard', loadComponent: () => import('./dashboard/dashboard.component').then(m => m.DashboardComponent) },
  { path: 'customers', loadComponent: () => import('./customers/customers.component').then(m => m.CustomersComponent) },
  { path: 'menu-items', loadComponent: () => import('./menu-items/menu-items.component').then(m => m.MenuItemsComponent) },
  { path: 'orders', loadComponent: () => import('./orders/orders.component').then(m => m.OrdersComponent) },
  { path: 'riders', loadComponent: () => import('./riders/riders.component').then(m => m.RidersComponent) },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
];
