import { Injectable } from '@angular/core';
import { Order } from './order.model';

@Injectable({ providedIn: 'root' })
export class OrderService {
  // TODO: เปลี่ยนเป็น HttpClient และ URL ของ API ที่ทีมตกลงกัน
  getAll(): Order[] {
    return [];
  }
}
