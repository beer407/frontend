import { Component } from '@angular/core';

@Component({
  selector: 'app-riders',
  standalone: true,
  templateUrl: './riders.component.html',
  styleUrl: './riders.component.css',
})
export class RidersComponent {
  // TODO: เพิ่มการโหลด ค้นหา เพิ่ม แก้ไข และลบข้อมูลไรเดอร์
}
