import { Component } from '@angular/core';

@Component({
  selector: 'app-orders',
  standalone: true,
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.css',
})
export class OrdersComponent {
  // TODO: เพิ่มการโหลด ค้นหา เพิ่ม แก้ไข และลบข้อมูลออเดอร์
}
