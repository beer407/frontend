export interface Rider {
  id: number;
  name: string;
  phone: string;
  status: 'available' | 'busy' | 'offline';
}
