import { Injectable } from '@angular/core';
import { MenuItem } from './menu-item.model';

@Injectable({ providedIn: 'root' })
export class MenuItemService {
  // TODO: เปลี่ยนเป็น HttpClient และ URL ของ API ที่ทีมตกลงกัน
  getAll(): MenuItem[] {
    return [];
  }
}
