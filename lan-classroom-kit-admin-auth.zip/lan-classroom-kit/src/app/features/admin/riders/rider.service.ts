import { Injectable } from '@angular/core';
import { Rider } from './rider.model';

@Injectable({ providedIn: 'root' })
export class RiderService {
  // TODO: เปลี่ยนเป็น HttpClient และ URL ของ API ที่ทีมตกลงกัน
  getAll(): Rider[] {
    return [];
  }
}
