import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-items',
  standalone: true,
  templateUrl: './menu-items.component.html',
  styleUrl: './menu-items.component.css',
})
export class MenuItemsComponent {
  // TODO: เพิ่มการโหลด ค้นหา เพิ่ม แก้ไข และลบข้อมูลเมนูอาหาร
}
