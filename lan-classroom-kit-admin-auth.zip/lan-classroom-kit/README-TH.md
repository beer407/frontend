# Starter Frontend — เจ้าของร้าน

โครงสร้าง Angular แบบ standalone สำหรับส่วน `admin` และ `auth`

## หมายเหตุ
- ไฟล์บริการ (`*.service.ts`) เป็นโครงเปล่า ให้เชื่อม API ภายหลัง
- ใน `auth.guard.ts` ตั้ง `isLoggedIn = false` ไว้เป็นตัวอย่าง ต้องเปลี่ยนเป็นการตรวจ token จริงก่อนใช้งาน
- นำโฟลเดอร์ `src` ไปวางทับ/รวมกับโปรเจกต์ Angular ของคุณ
